<?php 

defined('APP_TITLE') ? null : 				define("APP_TITLE"						, "skoolyf");

defined('ENABLED') ? null : 				define("ENABLED"						, 1);
defined('DISABLED') ? null : 				define("DISABLED"						, 0);

defined('CSNTRID') ? null : 				define("CSNTRID"						, 26);

defined('DEFENSEMODE') ? null : 			define("DEFENSEMODE"					, true);

defined('MAINTENANCEMODE') ? null : 		define("MAINTENANCEMODE"				, true);
defined('MAINTENANCEMESSAGE') ? null : 		define("MAINTENANCEMESSAGE"				, "Please wait.. skoolyf is being IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr.");
defined('MAINTENANCEIMAGE') ? null : 		define("MAINTENANCEIMAGE"				, "");

defined('MALE') ? null : 					define("MALE"							, 0);
defined('FEMALE') ? null : 					define("FEMALE"							, 1);

defined('ADMIN') ? null : 					define("ADMIN"							, 1);
defined('USER') ? null : 					define("USER"							, 0);

defined('PROFILE') ? null : 				define("PROFILE"						, "iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABrtJREFUeNrs3Vtv2kgYgOFvfMQQAqZJI6T+/1/WKiLQGmyM8fi0FyuspCRpUWxjp+8j7c1qN2ltXmbGRxXHcSUAXmWwCQACAQgEIBCAQAACAQgEIBCAQAACAUAgAIEABAIQCEAgAIEABAIQCEAgAIEAIBCAQAACAQgEIBCAQAACAQgEIBAABAIQCEAgAIEABAIQCEAgAIEABAIQCAACAQgEIBCAQAACAQgEIBCAQAACAUAgAIEABAIQCEAgAIEABAIQCEAgAIEAIBCAQAACAQgEIBCAQAACAQgEIBAABAK8y2ITdO94PEqWZSIi4jiOuK4reZ7L4XCQPM9FKSW2bct4PBbD4DvsmlQcxxWboV1VVYnWWsqyFK21FEXxcicoJVV1vhuUUjKZTMS27Toc0zRFKcVGJZDPoSgKiaJIyrJsZk5sGHU0YIo1ePv9/mzEaCK4+XzO9ItF+nCVZSlJkkie561M2Y7HIxuZEWSYsiyTKIpeXVc0JUkSsW2bqRYjyDCnVW3GcRLHMRubQIa3KG9qQd6n38UUC419q3cxejxf67BYZwQZzMJca93p74yiiA1PIMPQxhGrv5lmJUnCxieQfquq6mqLZgJhDdJ7x+PxKiPI88U6axFGEKZXbwjDkJ1AID3ekFf+9s6yTNI0ZUcwxervCNLl4d23/gyu67IzGEH6pSzLXnx7swYhkF5q8mrdjxiNRuwMplj9Y5rm1adXIv8fauZmKkaQXi7Q+/DBPN3GCwLplSzLejGCMHowxSKQd6Z53BvCCNLbNci1Rw7f9xlBCKSfHMe5aiSe54llMRlgitVTSilZLBYSBEHnC2WllIzHY3ZCW9uXx/4063g8ShAEnf2+u7s71h5MsYajy0s9DMMgDqZYw5tumabZydW9rDsYQRhFejJaEQgIBEyxuvrgKqVafSSPZVmsPxhBhrsOafvQ62QyYUMzggzXZDJp7ZE8pye8gxFkuN88liU3Nzet/OzpdMplJQQyfLe3t43f5ddmeCCQbjeuYYjv+1JVVSP/iIgsFgtGDwL5PDzPk9ls1sjP8n1fHMdhoxLI55tqTafTD8fBwvwKa0k2QTfm87mYpinb7faim6sMw5DFYsEVu1fC1bwdy7JMgiD4q1eojcdj8X3/6jdkEQg6p7WWw+EgaZrWD507vR/ddV2ZTCZcjEgg/4bTCz0dx+HyENYg+D2OHz9+1OuOh4eHiy4yPBwOstvtxLZtWSwWPD2xY2ztDqZSIlKfy7jkHSJlWcpmsxGttcRxLLvdjg1KIJ+LbdsvTvR5nndRIM/juvYrFphioRFVVcl6vRbXdWU2m8lyuZT9fi+j0egskLIsJQxDyfNcxuPxi8O5lmXJaDSSJElEKVWfcNztdpKmqdzf33NWnUX6MOR5LmmaSpqmkiSJ5HkuSimZz+dye3v75v/3+PgoWut6hLm/vz87IVgURf140zAM63MplmWJ53niuq64rstRL0aQfkmSRKIoqt8R+HwqdRIEgVRV9erlJkVRnJ0PCcPwLJDTeZDdbifb7baeemmtRWstSql6JPE8T6bT6UVTORBIY05TotOC+U93DZZlKUEQiFLqbCR5bXr01knBMAzr2F6b0p3+fRzHdbCz2ayVK4qZYuHVD2EURfWH9NJn8Z4uGfn9mqwgCGS73dajwHK5PLsgMYoi+fXr18W38J5+pu/73ENCIO2uLx4fHz/8mjXDMOTLly9nkWit69en/T6CRFEkP3/+/ND97UopsSxLlssl6xQCaVZRFPL9+/fG3iKllJK7u7u/urp3v9/Ler1u7MnxpmnKt2/fuLbrki81NsH7VqtVo69Yq6pKNpuN7Pf7d/+7OI5ls9k0+lqFoihktVqxUwmkGWma1mfCm17PbDabN8+qx3Es6/W6lccGaa15XTRTrOZGjz9903/o28kw5OvXry8O68ZxLE9PT60+U+vm5kYeHh7YwYwgH3M6XNqWsixltVrVI0mSJK3H0cXf6zPhkMYfpkJd/I6npyeZz+cvTgIO/e9FIGh0JHnrJCCYYoFvdUaQoX5oP+MHlxgJpBGO40iapp/qEo2qqni21gU4zAuwBgEIBCAQgEAAAgEIBCAQgEAAAgFAIACBAAQCEAhAIACBAAQCEAhAIACBACAQgEAAAgEIBCAQgEAAAgEIBCAQAAQCEAhAIACBAAQCEAhAIACBAAQCEAgAAgEIBCAQgEAAAgEIBCAQgEAAAgFAIACBAAQCEAhAIACBAAQCEAhAIACBACAQgEAAAgEIBCAQgEAAAgEIBCAQAAQCEAhAIEAb/hsA2c0VVSVx1ioAAAAASUVORK5CYII=");
defined('COVER') ? null : 					define("COVER"							, "iVBORw0KGgoAAAANSUhEUgAAAyAAAAEsCAYAAAA7Ldc6AAAABGdBTUEAALGOfPtRkwAAACBjSFJNAACHDwAAjA8AAP1SAACBQAAAfXkAAOmLAAA85QAAGcxzPIV3AAAKOWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAEjHnZZ3VFTXFofPvXd6oc0wAlKG3rvAANJ7k15FYZgZYCgDDjM0sSGiAhFFRJoiSFDEgNFQJFZEsRAUVLAHJAgoMRhFVCxvRtaLrqy89/Ly++Osb+2z97n77L3PWhcAkqcvl5cGSwGQyhPwgzyc6RGRUXTsAIABHmCAKQBMVka6X7B7CBDJy82FniFyAl8EAfB6WLwCcNPQM4BOB/+fpFnpfIHomAARm7M5GSwRF4g4JUuQLrbPipgalyxmGCVmvihBEcuJOWGRDT77LLKjmNmpPLaIxTmns1PZYu4V8bZMIUfEiK+ICzO5nCwR3xKxRoowlSviN+LYVA4zAwAUSWwXcFiJIjYRMYkfEuQi4uUA4EgJX3HcVyzgZAvEl3JJS8/hcxMSBXQdli7d1NqaQffkZKVwBALDACYrmcln013SUtOZvBwAFu/8WTLi2tJFRbY0tba0NDQzMv2qUP91829K3NtFehn4uWcQrf+L7a/80hoAYMyJarPziy2uCoDOLQDI3fti0zgAgKSobx3Xv7oPTTwviQJBuo2xcVZWlhGXwzISF/QP/U+Hv6GvvmckPu6P8tBdOfFMYYqALq4bKy0lTcinZ6QzWRy64Z+H+B8H/nUeBkGceA6fwxNFhImmjMtLELWbx+YKuGk8Opf3n5r4D8P+pMW5FonS+BFQY4yA1HUqQH7tBygKESDR+8Vd/6NvvvgwIH554SqTi3P/7zf9Z8Gl4iWDm/A5ziUohM4S8jMX98TPEqABAUgCKpAHykAd6ABDYAasgC1wBG7AG/iDEBAJVgMWSASpgA+yQB7YBApBMdgJ9oBqUAcaQTNoBcdBJzgFzoNL4Bq4AW6D+2AUTIBnYBa8BgsQBGEhMkSB5CEVSBPSh8wgBmQPuUG+UBAUCcVCCRAPEkJ50GaoGCqDqqF6qBn6HjoJnYeuQIPQXWgMmoZ+h97BCEyCqbASrAUbwwzYCfaBQ+BVcAK8Bs6FC+AdcCXcAB+FO+Dz8DX4NjwKP4PnEIAQERqiihgiDMQF8UeikHiEj6xHipAKpAFpRbqRPuQmMorMIG9RGBQFRUcZomxRnqhQFAu1BrUeVYKqRh1GdaB6UTdRY6hZ1Ec0Ga2I1kfboL3QEegEdBa6EF2BbkK3oy+ib6Mn0K8xGAwNo42xwnhiIjFJmLWYEsw+TBvmHGYQM46Zw2Kx8lh9rB3WH8vECrCF2CrsUexZ7BB2AvsGR8Sp4Mxw7rgoHA+Xj6vAHcGdwQ3hJnELeCm8Jt4G749n43PwpfhGfDf+On4Cv0CQJmgT7AghhCTCJkIloZVwkfCA8JJIJKoRrYmBRC5xI7GSeIx4mThGfEuSIemRXEjRJCFpB+kQ6RzpLuklmUzWIjuSo8gC8g5yM/kC+RH5jQRFwkjCS4ItsUGiRqJDYkjiuSReUlPSSXK1ZK5kheQJyeuSM1J4KS0pFymm1HqpGqmTUiNSc9IUaVNpf+lU6RLpI9JXpKdksDJaMm4ybJkCmYMyF2TGKQhFneJCYVE2UxopFykTVAxVm+pFTaIWU7+jDlBnZWVkl8mGyWbL1sielh2lITQtmhcthVZKO04bpr1borTEaQlnyfYlrUuGlszLLZVzlOPIFcm1yd2WeydPl3eTT5bfJd8p/1ABpaCnEKiQpbBf4aLCzFLqUtulrKVFS48vvacIK+opBimuVTyo2K84p6Ss5KGUrlSldEFpRpmm7KicpFyufEZ5WoWiYq/CVSlXOavylC5Ld6Kn0CvpvfRZVUVVT1Whar3qgOqCmrZaqFq+WpvaQ3WCOkM9Xr1cvUd9VkNFw08jT6NF454mXpOhmai5V7NPc15LWytca6tWp9aUtpy2l3audov2Ax2yjoPOGp0GnVu6GF2GbrLuPt0berCehV6iXo3edX1Y31Kfq79Pf9AAbWBtwDNoMBgxJBk6GWYathiOGdGMfI3yjTqNnhtrGEcZ7zLuM/5oYmGSYtJoct9UxtTbNN+02/R3Mz0zllmN2S1zsrm7+QbzLvMXy/SXcZbtX3bHgmLhZ7HVosfig6WVJd+y1XLaSsMq1qrWaoRBZQQwShiXrdHWztYbrE9Zv7WxtBHYHLf5zdbQNtn2iO3Ucu3lnOWNy8ft1OyYdvV2o/Z0+1j7A/ajDqoOTIcGh8eO6o5sxybHSSddpySno07PnU2c+c7tzvMuNi7rXM65Iq4erkWuA24ybqFu1W6P3NXcE9xb3Gc9LDzWepzzRHv6eO7yHPFS8mJ5NXvNelt5r/Pu9SH5BPtU+zz21fPl+3b7wX7efrv9HqzQXMFb0ekP/L38d/s/DNAOWBPwYyAmMCCwJvBJkGlQXlBfMCU4JvhI8OsQ55DSkPuhOqHC0J4wybDosOaw+XDX8LLw0QjjiHUR1yIVIrmRXVHYqLCopqi5lW4r96yciLaILoweXqW9KnvVldUKq1NWn46RjGHGnIhFx4bHHol9z/RnNjDn4rziauNmWS6svaxnbEd2OXuaY8cp40zG28WXxU8l2CXsTphOdEisSJzhunCruS+SPJPqkuaT/ZMPJX9KCU9pS8Wlxqae5Mnwknm9acpp2WmD6frphemja2zW7Fkzy/fhN2VAGasyugRU0c9Uv1BHuEU4lmmfWZP5Jiss60S2dDYvuz9HL2d7zmSue+63a1FrWWt78lTzNuWNrXNaV78eWh+3vmeD+oaCDRMbPTYe3kTYlLzpp3yT/LL8V5vDN3cXKBVsLBjf4rGlpVCikF84stV2a9021DbutoHt5turtn8sYhddLTYprih+X8IqufqN6TeV33zaEb9joNSydP9OzE7ezuFdDrsOl0mX5ZaN7/bb3VFOLy8qf7UnZs+VimUVdXsJe4V7Ryt9K7uqNKp2Vr2vTqy+XeNc01arWLu9dn4fe9/Qfsf9rXVKdcV17w5wD9yp96jvaNBqqDiIOZh58EljWGPft4xvm5sUmoqbPhziHRo9HHS4t9mqufmI4pHSFrhF2DJ9NProje9cv+tqNWytb6O1FR8Dx4THnn4f+/3wcZ/jPScYJ1p/0Pyhtp3SXtQBdeR0zHYmdo52RXYNnvQ+2dNt293+o9GPh06pnqo5LXu69AzhTMGZT2dzz86dSz83cz7h/HhPTM/9CxEXbvUG9g5c9Ll4+ZL7pQt9Tn1nL9tdPnXF5srJq4yrndcsr3X0W/S3/2TxU/uA5UDHdavrXTesb3QPLh88M+QwdP6m681Lt7xuXbu94vbgcOjwnZHokdE77DtTd1PuvriXeW/h/sYH6AdFD6UeVjxSfNTws+7PbaOWo6fHXMf6Hwc/vj/OGn/2S8Yv7ycKnpCfVEyqTDZPmU2dmnafvvF05dOJZ+nPFmYKf5X+tfa5zvMffnP8rX82YnbiBf/Fp99LXsq/PPRq2aueuYC5R69TXy/MF72Rf3P4LeNt37vwd5MLWe+x7ys/6H7o/ujz8cGn1E+f/gUDmPP8usTo0wAAAAlwSFlzAAAOxAAADsQBlSsOGwAAC/1JREFUeF7t3W1THNUaheEhiS+QiFFi9P//M/3mS1KlMERjYqzVZzbVB0kyEFhAz3VVddEMM5P55Jn7PL17763X63crAACAggebnwAAADdOgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAzd56vX63OQdgQV6+fLk5u5u+/PLL1cHBweY3AHaFCQgAAFAjQAAAgBoBArBQ7969u/MHALvHGhCAhXrx4sX087PPPpvWW9wFiY6Tk5PpPJ/pwYMHq4cPH64+//zz6TEAlk+AACzUCJAvvvhi9eTJk+n8tiVAxuL4BEh+f/v27Wpvb2+KkByJEgCWy3/lAbh1CZG//vprdXx8vDo9PZ2iBIBlEiAAC5Uv9eO4S+afaf4Zx/H69espRHKp1t9//z09D4DlECAAnHn16tUUAXOZSOS4yD///LM5u5pcevU+b968Wa3X69Uff/wxTUfOfy4A7icBAsCZP//88/9iI5dCJUpynL8s6vfff5/C4FNkbcrjx49Xjx492jzyX4mc/PsJkfz81OgB4HYJEICFGpc0bSvPzZf7RMh4XSIjj+VIAAy5RCqXSl3lEqnxuca/kbt0JURy5DzmzxnH+Gz5HLk8KxMSAO4fAQLAJF/oxxf9TBpy+VPOhzENyeNj8nGdi8UzBck05PDwcLpD1vsuz8pnTPi877IwAO42AQLAZD75SGjkGL9HzhMf88fnf78uuQ3v/v7+6uuvv14dHBxM+4Rc5K7sbQLA5QgQgIVKHIxjG7mkajw/k41MP+bvkSOPzR+fT0i2NV77MZmAZA+TTERyedZ8ncjYNwSA+0eAALB1FFzkOi/Dep+sDRnrQ8L0A+D+EiAAXGmS0Ta/41YmIwDcTwIEYKEuM9XIuovx/Mseee1lzF+7rVwelklLXpP4+ND+IQDcbQIEgCt/oc/rGjGQhe+Dy68A7jcBAsBkvsZiWx/aQPC65Ja7Y51JFp5fduICwN3iv+IAC3XZS51yp6lMM+av+9CR52bfjss4/x7bGLcHzmH6AXD/CRAAJplmXGYKcv7OVDchk4+s/4j8W42JCwA3S4AALNRlJw2Rzf+2WZCe5+S5VzHeYxtj08Mcph8AyyBAADiTsHj27Nk0abhocXkey9+Ojo5ufC1Gbg08br2b3dBtPAiwDAIEYKEuM2mYS1h8991304QjsTHeZ0w98rcEwVWN9/vYZxvTjzD9AFgOAQLAJBOH33777WxTwv39/dW33357Nun46quvpsfizZs3q5cvX340Iq4q75vF55GpiwABWA4BAsD0hT/xkQXf2+yKnuckEF68eLF55HqNO19F4uOiy8EAuJ8ECMBC5Qv8OD7m5ORkmmpE9t2Yu+g9xp2p8nO9Xk/n29rmM80Xn4+pCwDLIEAAmAJkfOHfJihOT0/Pnn98fLx59Hpk4fnYeDDTj5te7A5Al/+qAyzUCIQcH5Iv+7mkajw3ATCmIOO18/cZfx+PjVjY1njdeL/z5nFj+gGwPAIEYMedX1+RL/5ZD3JRWOQyraz7mMfD+0LiKhI2I35y210bDwIsjwAB2HG5xOl8hCQ+fv7557N1IZHzX3755T+L1K9zN/RMP4aDg4PNGQBLIkAAFmpcxrSN3GI3xmtyJELGJCS/Z63HOB9HHB4eTj+3NX/tXN573P0qkw8bDwIskwABYAqQfOGfT0LG+TwWzv89i8Sva52G6QfAbhAgAAs1Jg0XTRsu8vz582njwcePH6+ePHmyevr06bTreUIj75FJRx7L33McHR2tnj17tnn19i76XLmsayw+zyVhNh4EWK699Xq93f8yAXCv/PTTT9PPhw8fftLlTGMdSN5nPgG5quzxEZm6fPPNN9N5bv07buebxxM4ACyTAAFYqB9//HFzdjclNDJxydTj119/naYgCZxMYq4jdAC4m1yCBcCtysLzcWetrP0QHwDLJkAAuFXzndctPgdYPgECsFDzxd538Yj5rupZeJ51JgAsmwAB4NbMpx8WngPsBgECwK3Iuo9MQCJ36brOHdUBuLsECMBCnb/k6a4duR3vODf9ANgdAgSAW5HwiEePHtl4EGCHCBAAblV2XQdgdwgQgIUalzfd5SN7fuzv728+MQC7QIAAcGsy/bDxIMBu2Vuv1/+7CBcAtvD69evVycnJtIN5phhXlfD44YcfVg8e+P/CAHaJAAHgSt6+fTuFSPbyyC11LyvTj6dPn25+A2BXCBAAPkmmIKenp1OMZFfzbWT68f333093wAJgtwgQAK5NLssal2d9SBaeHx0dbX4DYJcIEACuXSYhCZFMRi5aJ/L8+fNp93MAdo8AAeDGZG1IQiTHWCeS8EiAALCbBAgANy5TkFevXq2Oj49Xh4eH9v4A2GECBAAAqHHzdQAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoEaAAAAANQIEAACoESAAAECNAAEAAGoECAAAUCNAAACAGgECAADUCBAAAKBGgAAAADUCBAAAqBEgAABAjQABAABqBAgAAFAjQAAAgBoBAgAA1AgQAACgRoAAAAA1AgQAAKgRIAAAQI0AAQAAagQIAABQI0AAAIAaAQIAANQIEAAAoGS1+hdz51JDSOTc4gAAAABJRU5ErkJggg==");

// ----------------------------------------- PHP MAILER  ------------------------------------------------------- \\

defined('EMAIL_PASS') ? null : 				define("EMAIL_PASS"					, "DhjkLmnOP2{}");
defined('EMAIL_ADDRESS') ? null : 			define("EMAIL_ADDRESS"				, "admin@kellyescape.com");

// ----------------------------------------- FACEBOOK PHP SDK  ------------------------------------------------------- \\

defined('APP_ID') ? null : 					define("APP_ID"						, "170997829744867");
defined('APP_SECRET') ? null : 				define("APP_SECRET"					, "d2cb18bdfb041ca4d1890dd68a6e17f6");

// ----------------------------------------- TWITTER SDK  ------------------------------------------------------- \\

defined('CONSUMER_KEY') ? null : 			define("CONSUMER_KEY"				, "bSR0sJHU2xovCHIjTw7A4A");
defined('CONSUMER_SECRET') ? null : 		define("CONSUMER_SECRET"			, "1zuPmNX1c0q6RAsOrDS0DAYquTlOqsf4iGKYg60YsPo");
defined('OAUTH_CALLBACK') ? null : 			define("OAUTH_CALLBACK"				, "http://kellyescape.com/public/functions/connecttwitter.php");

// ----------------------------------------- RECAPTCHA KEYS  ------------------------------------------------------- \\

defined('RECAPTCHA_PUBLIC') ? null : 		define("RECAPTCHA_PUBLIC"			, "6Lcgl-MSAAAAAF6J4o0d0rmrbx0cVc8nsyoT38XH");
defined('RECAPTCHA_PRIVATE') ? null : 		define("RECAPTCHA_PRIVATE"			, "6Lcgl-MSAAAAAHHYvj1hzBmO47kmsVxccvL52jo2");

// ----------------------------------------- USERS TABLE  ------------------------------------------------------- \\
defined('T_USERS') ? null :					define("T_USERS"					, "users");
defined('C_USER_ID') ? null : 				define("C_USER_ID"					, "id");
defined('C_USER_USERNAME') ? null : 		define("C_USER_USERNAME"			, "username");
defined('C_USER_PASSWORD') ? null : 		define("C_USER_PASSWORD"			, "password");
defined('C_USER_EMAIL') ? null : 			define("C_USER_EMAIL"				, "email");
defined('C_USER_FIRSTNAME') ? null : 		define("C_USER_FIRSTNAME"			, "firstname");
defined('C_USER_MIDDLENAME') ? null : 		define("C_USER_MIDDLENAME"			, "middlename");
defined('C_USER_LASTNAME') ? null : 		define("C_USER_LASTNAME"			, "lastname");
defined('C_USER_GENDER') ? null : 			define("C_USER_GENDER"				, "gender");
defined('C_USER_ADDRESS') ? null : 			define("C_USER_ADDRESS"				, "address");
defined('C_USER_MOTO') ? null : 			define("C_USER_MOTO"				, "moto");
defined('C_USER_BIRTHDATE') ? null : 		define("C_USER_BIRTHDATE"			, "birthdate");
defined('C_USER_PICTURE') ? null : 			define("C_USER_PICTURE"				, "picture");
defined('C_USER_COVER') ? null : 			define("C_USER_COVER"				, "cover");
defined('C_USER_NUMBER') ? null : 			define("C_USER_NUMBER"				, "number");
defined('C_USER_DATE') ? null :				define("C_USER_DATE"				, "date");
defined('C_USER_PENDING') ? null : 			define("C_USER_PENDING"				, "pending");
defined('C_USER_ENABLED') ? null : 			define("C_USER_ENABLED"				, "enabled");
defined('C_USER_OAUTH_UID') ? null :		define("C_USER_OAUTH_UID"			, "oauth_uid");
defined('C_USER_OAUTH_PROVIDER') ? null :	define("C_USER_OAUTH_PROVIDER"		, "oauth_provider");
defined('C_USER_COMMENTS') ? null :			define("C_USER_COMMENTS"			, "comments");
defined('C_USER_FBCOMMENTS') ? null :		define("C_USER_FBCOMMENTS"			, "fbcomments");

// ----------------------------------------- SCHOOLS TABLE  ------------------------------------------------------- \\
defined('T_SCHOOLS') ? null :				define("T_SCHOOLS"					, "schools");
defined('C_SCHOOL_ID') ? null : 			define("C_SCHOOL_ID"				, "id");
defined('C_SCHOOL_PENDING') ? null : 		define("C_SCHOOL_PENDING"			, "pending");
defined('C_SCHOOL_ENABLED') ? null : 		define("C_SCHOOL_ENABLED"			, "enabled");
defined('C_SCHOOL_NAME') ? null : 			define("C_SCHOOL_NAME"				, "name");
defined('C_SCHOOL_ADDRESS') ? null : 		define("C_SCHOOL_ADDRESS"			, "address");
defined('C_SCHOOL_PICTURE') ? null : 		define("C_SCHOOL_PICTURE"			, "picture");
defined('C_SCHOOL_NUMBER') ? null : 		define("C_SCHOOL_NUMBER"			, "number");
defined('C_SCHOOL_EMAIL') ? null : 			define("C_SCHOOL_EMAIL"				, "email");
defined('C_SCHOOL_ABOUT') ? null : 			define("C_SCHOOL_ABOUT"				, "about");
defined('C_SCHOOL_LOGO') ? null : 			define("C_SCHOOL_LOGO"				, "logo");
defined('C_SCHOOL_HISTORY') ? null : 		define("C_SCHOOL_HISTORY"			, "history");
defined('C_SCHOOL_VISIONMISSION') ? null : 	define("C_SCHOOL_VISIONMISSION"		, "visionmission");
defined('C_SCHOOL_COREVALUES') ? null : 	define("C_SCHOOL_COREVALUES"		, "corevalues");
defined('C_SCHOOL_DATE') ? null : 			define("C_SCHOOL_DATE"				, "date");
defined('C_SCHOOL_COMMENTS') ? null :		define("C_SCHOOL_COMMENTS"			, "comments");
defined('C_SCHOOL_FBCOMMENTS') ? null :		define("C_SCHOOL_FBCOMMENTS"		, "fbcomments");

// ----------------------------------------- BATCHS TABLE  ------------------------------------------------------- \\
defined('T_BATCHS') ? null :				define("T_BATCHS"					, "batchs");
defined('C_BATCH_ID') ? null : 				define("C_BATCH_ID"					, "id");
defined('C_BATCH_PENDING') ? null : 		define("C_BATCH_PENDING"			, "pending");
defined('C_BATCH_ENABLED') ? null : 		define("C_BATCH_ENABLED"			, "enabled");
defined('C_BATCH_FROMYEAR') ? null : 		define("C_BATCH_FROMYEAR"			, "fromyear");
defined('C_BATCH_SCHOOLID') ? null : 		define("C_BATCH_SCHOOLID"			, "schoolid");
defined('C_BATCH_ABOUT') ? null : 			define("C_BATCH_ABOUT"				, "about");
defined('C_BATCH_PICTURE') ? null : 		define("C_BATCH_PICTURE"			, "picture");
defined('C_BATCH_DATE') ? null : 			define("C_BATCH_DATE"				, "date");
defined('C_BATCH_COMMENTS') ? null :		define("C_BATCH_COMMENTS"			, "comments");
defined('C_BATCH_FBCOMMENTS') ? null :		define("C_BATCH_FBCOMMENTS"			, "fbcomments");
defined('C_BATCH_PUBDATE') ? null :			define("C_BATCH_PUBDATE"			, "pubdate");
defined('C_BATCH_PUBLISHED') ? null :		define("C_BATCH_PUBLISHED"			, "published");

// ----------------------------------------- SECTIONS TABLE  ------------------------------------------------------- \\
defined('T_SECTIONS') ? null :				define("T_SECTIONS"					, "sections");
defined('C_SECTION_ID') ? null : 			define("C_SECTION_ID"				, "id");
defined('C_SECTION_PENDING') ? null : 		define("C_SECTION_PENDING"			, "pending");
defined('C_SECTION_ENABLED') ? null : 		define("C_SECTION_ENABLED"			, "enabled");
defined('C_SECTION_SCHOOLID') ? null : 		define("C_SECTION_SCHOOLID"			, "schoolid");
defined('C_SECTION_BATCHID') ? null : 		define("C_SECTION_BATCHID"			, "batchid");
defined('C_SECTION_NAME') ? null : 			define("C_SECTION_NAME"				, "name");
defined('C_SECTION_ABOUT') ? null : 		define("C_SECTION_ABOUT"			, "about");
defined('C_SECTION_ADVISERMESSAGE') ? null :define("C_SECTION_ADVISERMESSAGE"	, "advisermessage");
defined('C_SECTION_PICTURE') ? null : 		define("C_SECTION_PICTURE"			, "picture");
defined('C_SECTION_DATE') ? null : 			define("C_SECTION_DATE"				, "date");
defined('C_SECTION_COMMENTS') ? null :		define("C_SECTION_COMMENTS"			, "comments");
defined('C_SECTION_FBCOMMENTS') ? null :	define("C_SECTION_FBCOMMENTS"		, "fbcomments");

// ----------------------------------------- CLUBS TABLE  ------------------------------------------------------- \\
defined('T_CLUBS') ? null :					define("T_CLUBS"					, "clubs");
defined('C_CLUB_ID') ? null : 				define("C_CLUB_ID"					, "id");
defined('C_CLUB_SCHOOLID') ? null : 		define("C_CLUB_SCHOOLID"			, "schoolid");
defined('C_CLUB_NAME') ? null : 			define("C_CLUB_NAME"				, "name");
defined('C_CLUB_ABOUT') ? null : 			define("C_CLUB_ABOUT"				, "about");
defined('C_CLUB_LOGO') ? null : 			define("C_CLUB_LOGO"				, "logo");
defined('C_CLUB_COVER') ? null : 			define("C_CLUB_COVER"				, "cover");
defined('C_CLUB_COMMENTS') ? null :			define("C_CLUB_COMMENTS"			, "comments");
defined('C_CLUB_FBCOMMENTS') ? null :		define("C_CLUB_FBCOMMENTS"			, "fbcomments");
defined('C_CLUB_PENDING') ? null : 			define("C_CLUB_PENDING"				, "pending");
defined('C_CLUB_ENABLED') ? null : 			define("C_CLUB_ENABLED"				, "enabled");
defined('C_CLUB_DATE') ? null : 			define("C_CLUB_DATE"				, "date");

// ----------------------------------------- GROUPS TABLE  ------------------------------------------------------- \\
defined('T_GROUPS') ? null :				define("T_GROUPS"					, "groups");
defined('C_GROUP_ID') ? null : 				define("C_GROUP_ID"					, "id");
defined('C_GROUP_SCHOOLID') ? null : 		define("C_GROUP_SCHOOLID"			, "schoolid");
defined('C_GROUP_NAME') ? null : 			define("C_GROUP_NAME"				, "name");
defined('C_GROUP_ABOUT') ? null : 			define("C_GROUP_ABOUT"				, "about");
defined('C_GROUP_LOGO') ? null : 			define("C_GROUP_LOGO"				, "logo");
defined('C_GROUP_COVER') ? null : 			define("C_GROUP_COVER"				, "cover");
defined('C_GROUP_COMMENTS') ? null :		define("C_GROUP_COMMENTS"			, "comments");
defined('C_GROUP_FBCOMMENTS') ? null :		define("C_GROUP_FBCOMMENTS"			, "fbcomments");
defined('C_GROUP_PENDING') ? null : 		define("C_GROUP_PENDING"			, "pending");
defined('C_GROUP_ENABLED') ? null : 		define("C_GROUP_ENABLED"			, "enabled");
defined('C_GROUP_DATE') ? null : 			define("C_GROUP_DATE"				, "date");


// ----------------------------------------- SCHOOL ADMINS TABLE  ------------------------------------------------------- \\
defined('T_SCHOOLUSERS') ? null :			define("T_SCHOOLUSERS"				, "schoolusers");
defined('C_SCHOOLUSER_ID') ? null : 		define("C_SCHOOLUSER_ID"			, "id");
defined('C_SCHOOLUSER_PENDING') ? null : 	define("C_SCHOOLUSER_PENDING"		, "pending");
defined('C_SCHOOLUSER_ENABLED') ? null : 	define("C_SCHOOLUSER_ENABLED"		, "enabled");
defined('C_SCHOOLUSER_SCHOOLID') ? null : 	define("C_SCHOOLUSER_SCHOOLID"		, "schoolid");
defined('C_SCHOOLUSER_USERID') ? null : 	define("C_SCHOOLUSER_USERID"		, "userid");
defined('C_SCHOOLUSER_LEVEL') ? null : 		define("C_SCHOOLUSER_LEVEL"			, "level");
defined('C_SCHOOLUSER_ROLE') ? null : 		define("C_SCHOOLUSER_ROLE"			, "role");
defined('C_SCHOOLUSER_DATE') ? null : 		define("C_SCHOOLUSER_DATE"			, "date");

// ----------------------------------------- BATCH USERS TABLE  ------------------------------------------------------- \\
defined('T_BATCHUSERS') ? null :			define("T_BATCHUSERS"				, "batchusers");
defined('C_BATCHUSER_ID') ? null : 			define("C_BATCHUSER_ID"				, "id");
defined('C_BATCHUSER_PENDING') ? null : 	define("C_BATCHUSER_PENDING"		, "pending");
defined('C_BATCHUSER_ENABLED') ? null : 	define("C_BATCHUSER_ENABLED"		, "enabled");
defined('C_BATCHUSER_SCHOOLID') ? null : 	define("C_BATCHUSER_SCHOOLID"		, "schoolid");
defined('C_BATCHUSER_BATCHID') ? null : 	define("C_BATCHUSER_BATCHID"		, "batchid");
defined('C_BATCHUSER_USERID') ? null : 		define("C_BATCHUSER_USERID"			, "userid");
defined('C_BATCHUSER_LEVEL') ? null : 		define("C_BATCHUSER_LEVEL"			, "level");
defined('C_BATCHUSER_ROLE') ? null : 		define("C_BATCHUSER_ROLE"			, "role");
defined('C_BATCHUSER_DATE') ? null : 		define("C_BATCHUSER_DATE"			, "date");

// ----------------------------------------- SECTION USERS TABLE  ------------------------------------------------------- \\
defined('T_SECTIONUSERS') ? null :			define("T_SECTIONUSERS"				, "sectionusers");
defined('C_SECTIONUSER_ID') ? null : 		define("C_SECTIONUSER_ID"			, "id");
defined('C_SECTIONUSER_PENDING') ? null : 	define("C_SECTIONUSER_PENDING"		, "pending");
defined('C_SECTIONUSER_ENABLED') ? null : 	define("C_SECTIONUSER_ENABLED"		, "enabled");
defined('C_SECTIONUSER_USERID') ? null : 	define("C_SECTIONUSER_USERID"		, "userid");
defined('C_SECTIONUSER_SCHOOLID') ? null : 	define("C_SECTIONUSER_SCHOOLID"		, "schoolid");
defined('C_SECTIONUSER_BATCHID') ? null : 	define("C_SECTIONUSER_BATCHID"		, "batchid");
defined('C_SECTIONUSER_SECTIONID') ? null : define("C_SECTIONUSER_SECTIONID"	, "sectionid");
defined('C_SECTIONUSER_LEVEL') ? null : 	define("C_SECTIONUSER_LEVEL"		, "level");
defined('C_SECTIONUSER_ROLE') ? null : 		define("C_SECTIONUSER_ROLE"			, "role");
defined('C_SECTIONUSER_DATE') ? null : 		define("C_SECTIONUSER_DATE"			, "date");

// ----------------------------------------- CLUB USERS TABLE  ------------------------------------------------------- \\
defined('T_CLUBUSERS') ? null :				define("T_CLUBUSERS"				, "clubusers");
defined('C_CLUBUSER_ID') ? null : 			define("C_CLUBUSER_ID"				, "id");
defined('C_CLUBUSER_USERID') ? null : 		define("C_CLUBUSER_USERID"			, "userid");
defined('C_CLUBUSER_CLUBID') ? null : 		define("C_CLUBUSER_CLUBID"			, "clubid");
defined('C_CLUBUSER_LEVEL') ? null : 		define("C_CLUBUSER_LEVEL"			, "level");
defined('C_CLUBUSER_ROLE') ? null : 		define("C_CLUBUSER_ROLE"			, "role");
defined('C_CLUBUSER_PENDING') ? null : 		define("C_CLUBUSER_PENDING"			, "pending");
defined('C_CLUBUSER_ENABLED') ? null : 		define("C_CLUBUSER_ENABLED"			, "enabled");
defined('C_CLUBUSER_DATE') ? null : 		define("C_CLUBUSER_DATE"			, "date");

// ----------------------------------------- GROUP USERS TABLE  ------------------------------------------------------- \\
defined('T_GROUPUSERS') ? null :			define("T_GROUPUSERS"				, "groupusers");
defined('C_GROUPUSER_ID') ? null : 			define("C_GROUPUSER_ID"				, "id");
defined('C_GROUPUSER_USERID') ? null : 		define("C_GROUPUSER_USERID"			, "userid");
defined('C_GROUPUSER_GROUPID') ? null : 	define("C_GROUPUSER_GROUPID"		, "groupid");
defined('C_GROUPUSER_LEVEL') ? null : 		define("C_GROUPUSER_LEVEL"			, "level");
defined('C_GROUPUSER_ROLE') ? null : 		define("C_GROUPUSER_ROLE"			, "role");
defined('C_GROUPUSER_PENDING') ? null : 	define("C_GROUPUSER_PENDING"		, "pending");
defined('C_GROUPUSER_ENABLED') ? null : 	define("C_GROUPUSER_ENABLED"		, "enabled");
defined('C_GROUPUSER_DATE') ? null : 		define("C_GROUPUSER_DATE"			, "date");

// ----------------------------------------- SUPER ADMINS TABLE  ------------------------------------------------------- \\
defined('T_SUPERADMINS') ? null :			define("T_SUPERADMINS"				, "superadmins");
defined('C_SUPERADMIN_ID') ? null : 		define("C_SUPERADMIN_ID"			, "id");
defined('C_SUPERADMIN_USERID') ? null : 	define("C_SUPERADMIN_USERID"		, "userid");
defined('C_SUPERADMIN_DATE') ? null : 		define("C_SUPERADMIN_DATE"			, "date");

// ----------------------------------------- FRIENDS TABLE  ------------------------------------------------------- \\
defined('T_FRIENDS') ? null :				define("T_FRIENDS"					, "friends");
defined('C_FRIEND_ID') ? null : 			define("C_FRIEND_ID"				, "id");
defined('C_FRIEND_USERID') ? null : 		define("C_FRIEND_USERID"			, "userid");
defined('C_FRIEND_TOUSERID') ? null : 		define("C_FRIEND_TOUSERID"			, "touserid");
defined('C_FRIEND_PENDING') ? null : 		define("C_FRIEND_PENDING"			, "pending");
defined('C_FRIEND_ENABLED') ? null : 		define("C_FRIEND_ENABLED"			, "enabled");
defined('C_FRIEND_DATE') ? null : 			define("C_FRIEND_DATE"				, "date");

// ----------------------------------------- COMMENTS TABLE  ------------------------------------------------------- \\
defined('T_COMMENTS') ? null :				define("T_COMMENTS"					, "comments");
defined('C_COMMENT_ID') ? null : 			define("C_COMMENT_ID"				, "id");
defined('C_COMMENT_COMMENT') ? null : 		define("C_COMMENT_COMMENT"			, "comment");
defined('C_COMMENT_USERID') ? null : 		define("C_COMMENT_USERID"			, "userid");
defined('C_COMMENT_ITEMID') ? null : 		define("C_COMMENT_ITEMID"			, "itemid");
defined('C_COMMENT_ITEMTYPE') ? null : 		define("C_COMMENT_ITEMTYPE"			, "itemtype");
defined('C_COMMENT_PENDING') ? null : 		define("C_COMMENT_PENDING"			, "pending");
defined('C_COMMENT_ENABLED') ? null : 		define("C_COMMENT_ENABLED"			, "enabled");
defined('C_COMMENT_DATE') ? null : 			define("C_COMMENT_DATE"				, "date");

// ----------------------------------------- STATUSES TABLE  ------------------------------------------------------- \\
defined('T_STATUSES') ? null :				define("T_STATUSES"					, "statuses");
defined('C_STATUS_ID') ? null : 			define("C_STATUS_ID"				, "id");
defined('C_STATUS_STATUS') ? null : 		define("C_STATUS_STATUS"			, "status");
defined('C_STATUS_ITEMID') ? null : 		define("C_STATUS_ITEMID"			, "itemid");
defined('C_STATUS_ITEMTYPE') ? null : 		define("C_STATUS_ITEMTYPE"			, "itemtype");
defined('C_STATUS_PENDING') ? null : 		define("C_STATUS_PENDING"			, "pending");
defined('C_STATUS_ENABLED') ? null : 		define("C_STATUS_ENABLED"			, "enabled");
defined('C_STATUS_DATE') ? null : 			define("C_STATUS_DATE"				, "date");

// ----------------------------------------- PICTURES TABLE  ------------------------------------------------------- \\
defined('T_PICTURES') ? null :				define("T_PICTURES"					, "pictures");
defined('C_PICTURE_ID') ? null : 			define("C_PICTURE_ID"				, "id");
defined('C_PICTURE_ITEMID') ? null : 		define("C_PICTURE_ITEMID"			, "itemid");
defined('C_PICTURE_ITEMTYPE') ? null : 		define("C_PICTURE_ITEMTYPE"			, "itemtype");
defined('C_PICTURE_PICTURE') ? null : 		define("C_PICTURE_PICTURE"			, "picture");
defined('C_PICTURE_PENDING') ? null : 		define("C_PICTURE_PENDING"			, "pending");
defined('C_PICTURE_ENABLED') ? null : 		define("C_PICTURE_ENABLED"			, "enabled");
defined('C_PICTURE_DATE') ? null : 			define("C_PICTURE_DATE"				, "date");

// ----------------------------------------- JOBS TABLE  ------------------------------------------------------- \\
defined('T_JOBS') ? null :					define("T_JOBS"						, "jobs");
defined('C_JOB_ID') ? null : 				define("C_JOB_ID"					, "id");
defined('C_JOB_USERID') ? null : 			define("C_JOB_USERID"				, "userid");
defined('C_JOB_ROLE') ? null : 				define("C_JOB_ROLE"					, "role");
defined('C_JOB_COMPANY') ? null : 			define("C_JOB_COMPANY"				, "company");
defined('C_JOB_ADDRESS') ? null : 			define("C_JOB_ADDRESS"				, "address");
defined('C_JOB_FROMDATE') ? null : 			define("C_JOB_FROMDATE"				, "fromdate");
defined('C_JOB_TODATE') ? null : 			define("C_JOB_TODATE"				, "todate");
defined('C_JOB_PRESENT') ? null : 			define("C_JOB_PRESENT"				, "present");
defined('C_JOB_PENDING') ? null : 			define("C_JOB_PENDING"				, "pending");
defined('C_JOB_ENABLED') ? null : 			define("C_JOB_ENABLED"				, "enabled");
defined('C_JOB_DATE') ? null : 				define("C_JOB_DATE"					, "date");

// ----------------------------------------- NOTIFICATIONS TABLE  ------------------------------------------------------- \\
defined('T_NOTIFICATIONS') ? null :				define("T_NOTIFICATIONS"				, "notifications");
defined('C_NOTIFICATION_ID') ? null : 			define("C_NOTIFICATION_ID"				, "id");
defined('C_NOTIFICATION_FROMUSERID') ? null : 	define("C_NOTIFICATION_FROMUSERID"		, "fromuserid");
defined('C_NOTIFICATION_TOUSERID') ? null : 	define("C_NOTIFICATION_TOUSERID"		, "touserid");
defined('C_NOTIFICATION_TITLE') ? null : 		define("C_NOTIFICATION_TITLE"			, "title");
defined('C_NOTIFICATION_ITEMID') ? null : 		define("C_NOTIFICATION_ITEMID"			, "itemid");
defined('C_NOTIFICATION_ITEMTYPE') ? null : 	define("C_NOTIFICATION_ITEMTYPE"		, "itemtype");
defined('C_NOTIFICATION_PENDING') ? null : 		define("C_NOTIFICATION_PENDING"			, "pending");
defined('C_NOTIFICATION_ENABLED') ? null : 		define("C_NOTIFICATION_ENABLED"			, "enabled");
defined('C_NOTIFICATION_DATE') ? null : 		define("C_NOTIFICATION_DATE"			, "date");

// ----------------------------------------- ACHIEVEMENTS TABLE  ------------------------------------------------------- \\
defined('T_ACHIEVEMENTS') ? null :				define("T_ACHIEVEMENTS"					, "achievements");
defined('C_ACHIEVEMENT_ID') ? null : 			define("C_ACHIEVEMENT_ID"				, "id");
defined('C_ACHIEVEMENT_BATCHID') ? null : 		define("C_ACHIEVEMENT_BATCHID"			, "batchid");
defined('C_ACHIEVEMENT_ITEMID') ? null : 		define("C_ACHIEVEMENT_ITEMID"			, "itemid");
defined('C_ACHIEVEMENT_ITEMTYPE') ? null : 		define("C_ACHIEVEMENT_ITEMTYPE"			, "itemtype");
defined('C_ACHIEVEMENT_NAME') ? null : 			define("C_ACHIEVEMENT_NAME"				, "name");
defined('C_ACHIEVEMENT_ABOUT') ? null : 		define("C_ACHIEVEMENT_ABOUT"			, "about");
defined('C_ACHIEVEMENT_PENDING') ? null : 		define("C_ACHIEVEMENT_PENDING"			, "pending");
defined('C_ACHIEVEMENT_ENABLED') ? null : 		define("C_ACHIEVEMENT_ENABLED"			, "enabled");
defined('C_ACHIEVEMENT_DATE') ? null : 			define("C_ACHIEVEMENT_DATE"				, "date");

// ----------------------------------------- LOGS TABLE  ------------------------------------------------------- \\
defined('T_LOGS') ? null :					define("T_LOGS"						, "logs");
defined('C_LOGS_ID') ? null : 				define("C_LOGS_ID"					, "id");
defined('C_LOGS_USER_ID') ? null : 			define("C_LOGS_USER_ID"				, "user_id");
defined('C_LOGS_IP') ? null : 				define("C_LOGS_IP"					, "ip");
defined('C_LOGS_PLATFORM') ? null : 		define("C_LOGS_PLATFORM"			, "platform");
defined('C_LOGS_DATE') ? null : 			define("C_LOGS_DATE"				, "date");
defined('C_LOGS_ACTION') ? null : 			define("C_LOGS_ACTION"				, "action");

// ----------------------------------------- HITS TABLE  ------------------------------------------------------- \\
defined('T_HITS') ? null :					define("T_HITS"						, "hits");
defined('C_HITS_ID') ? null : 				define("C_HITS_ID"					, "id");
defined('C_HITS_NAME') ? null : 			define("C_HITS_NAME"				, "name");
defined('C_HITS_PLATFORM') ? null : 		define("C_HITS_PLATFORM"			, "platform");
defined('C_HITS_USER_ID') ? null : 			define("C_HITS_USER_ID"				, "user_id");
defined('C_HITS_DATE') ? null : 			define("C_HITS_DATE"				, "date");

// ----------------------------------------- PENDINGS TABLE  ------------------------------------------------------- \\
defined('T_PENDINGS') ? null :				define("T_PENDINGS"					, "PENDINGS");
defined('C_PENDING_ID') ? null : 			define("C_PENDING_ID"				, "id");
defined('C_PENDING_ITEMID') ? null : 		define("C_PENDING_ITEMID"			, "itemid");
defined('C_PENDING_ITEMTYPE') ? null : 		define("C_PENDING_ITEMTYPE"			, "itemtype");
defined('C_PENDING_DATE') ? null : 			define("C_PENDING_DATE"				, "date");

// ----------------------------------------- ITEM TYPES ------------------------------------------------------- \\
defined('USER') ? null :					define("USER"						, "USER");
defined('SCHOOL') ? null :					define("SCHOOL"						, "SCHOOL");
defined('BATCH') ? null :					define("BATCH"						, "BATCH");
defined('SECTION') ? null :					define("SECTION"					, "SECTION");
defined('SCHOOLUSER') ? null :				define("SCHOOLUSER"					, "SCHOOLUSER");
defined('BATCHUSER') ? null :				define("BATCHUSER"					, "BATCHUSER");
defined('SECTIONUSER') ? null :				define("SECTIONUSER"				, "SECTIONUSER");

?>